﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    public Text ScoreTextbox;
    public string ScoreTextPrefix;

    private int score;

    // Start is called before the first frame update
    void Start()
    {
        if(Instance == null)
        {
            Instance = this;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (score == 4)
        {
            StartCoroutine(WaitForIt(1.0F));
        }
    }
    IEnumerator WaitForIt(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        SceneManager.LoadScene(1);
    }

    IEnumerator WaitForIt1(float waitTime1)
    {
        yield return new WaitForSeconds(waitTime1);
        SceneManager.LoadScene(2);
    }

    public void UpdateScore(int _score)
    {
        score += _score;
        ScoreTextbox.text = ScoreTextPrefix + score;
    }

    public int GetScore()
    {
        return score;
    }

    public void ResetGame()
    {
        SceneManager.LoadScene(0);
    }
}
